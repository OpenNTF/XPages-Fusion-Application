## XPages Bluemix Fusion Project

This project provides an XPages application that demonstrates how to 
use a number of different services from the Bluemix catalog. The initial
set of services includes: Cloudant DB, Watson Language Translation, Watson 
Text to Speech, and Watson Image Recognition.

[![Deploy to Bluemix](https://bluemix.net/deploy/button.png)](https://bluemix.net/deploy?repository=https://github.com/OpenNTF/XPages-Fusion-Application)


